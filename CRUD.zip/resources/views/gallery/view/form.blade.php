<div class="form-group">
    Select images: <input type="file" name="cover_image" multiple>
</div>