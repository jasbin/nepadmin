
<div class="form-group float-right">
    <div class="searchbar">
        <input class="search_input" type="text" name="search" placeholder="Search...">
        <p class="search_icon"><i class="fas fa-search"></i></p>
    </div>
</div>