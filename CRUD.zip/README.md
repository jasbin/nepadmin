# adminlte3crud
a crud application using adminlte
perform: npm run watch
to install all npm packages for admin-lte3
